;<?php die("Unreadable"); ?>
DatabaseName=gfotobr_sb04
UserName=gfotobr_sb04
Password=zXpn3j1m2E2OFQ7e
Port=3306
HostName=localhost
protocol=unix
RvsUserName=gfotobr